package com.clarifi.phoenix.apiserver.handlers.accesslog;

import io.undertow.server.handlers.accesslog.AccessLogReceiver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Slf4jAccessLogReceiver implements AccessLogReceiver
{
  private final Logger logger = LoggerFactory.getLogger( "ACCESS" );

  public Slf4jAccessLogReceiver()
  {
  }

  @Override
  public void logMessage( String message )
  {
    logger.info( "{}", message );
  }
}
