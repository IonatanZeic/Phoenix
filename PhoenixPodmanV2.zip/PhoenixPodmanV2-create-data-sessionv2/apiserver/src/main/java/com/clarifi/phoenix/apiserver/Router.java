package com.clarifi.phoenix.apiserver;

import java.nio.file.Paths;
import java.util.Set;

import com.clarifi.phoenix.apiserver.handlers.*;
import com.clarifi.phoenix.apiserver.handlers.accesslog.Slf4jAccessLogReceiver;
import io.undertow.Handlers;
import io.undertow.attribute.RequestLineAttribute;
import io.undertow.predicate.Predicates;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.server.RoutingHandler;
import io.undertow.server.handlers.BlockingHandler;
import io.undertow.server.handlers.ExceptionHandler;
import io.undertow.server.handlers.accesslog.AccessLogHandler;
import io.undertow.server.handlers.encoding.ContentEncodingRepository;
import io.undertow.server.handlers.encoding.EncodingHandler;
import io.undertow.server.handlers.encoding.GzipEncodingProvider;
import io.undertow.server.handlers.resource.PathResourceManager;
import io.undertow.server.handlers.resource.ResourceHandler;
import io.undertow.util.Headers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Router
{
  private static final Logger EXCEPTION_LOGGER = LoggerFactory.getLogger( "EXCEPTION" );

  public static HttpHandler replHandler()
  {
    return ( HttpServerExchange exchange ) ->
    {
      exchange.getResponseHeaders().put( Headers.CONTENT_TYPE, "text/plain" );
      exchange.getResponseSender().send( exchange.getQueryParameters().get( "command" ).getFirst() );
    };
  }

  public static HttpHandler exceptionThrower()
  {
    return ( HttpServerExchange exchange ) ->
    {
      throw Status.INTERNAL_SERVER_ERROR.new StatusException( "foof" );
    };
  }

  public static HttpHandler runtimeThrower()
  {
    return ( HttpServerExchange exchange ) ->
    {
      throw new RuntimeException( "bebabu" );
    };
  }

  //---------------

  private static final String API_PREFIX = "/api";

  public static final HttpHandler REST_ROUTES = new RoutingHandler()
    .get(  API_PREFIX + "/myRoute",        constantStringHandler( "GET - My Route") )
    .post( API_PREFIX + "/myRoute",        constantStringHandler( "POST - My Route") )
    .get(  API_PREFIX + "/myOtherRoute",   constantStringHandler( "GET - My Other Route" ) )
    .get(  API_PREFIX + "/myRoutePrefix*", constantStringHandler( "GET - My Prefixed Route" ) )
    .get(  API_PREFIX + "/repl/{command}", replHandler() )
    .get(  API_PREFIX + "/ex",             exceptionThrower() )
    .get(  API_PREFIX + "/rt",             runtimeThrower() )
    .setFallbackHandler( notFoundHandler() );

  public static final ResourceHandler ROUTES =
    new ResourceHandler( new PathResourceManager( Paths.get( "./static_web" ), 100 ), REST_ROUTES )
      .addWelcomeFiles( "index.html" );

  public static final HttpHandler ROOT = Handlers.exceptionHandler( ROUTES )
    .addExceptionHandler( Status.StatusException.class, serverExceptionHandler() )
    .addExceptionHandler( Throwable.class, serverErrorHandler() );

  public static HttpHandler ROUTER = MiddlewareBuilder.begin( handler -> securityHeaders( handler ) )
    .next( Router::gzip )
    .next( BlockingHandler::new )
    .next( Router::accessLog )
    .complete( ROOT );

  public static HttpHandler gzip( HttpHandler next )
  {
    return new EncodingHandler( new ContentEncodingRepository()
      .addEncodingHandler( "gzip",
        // This 1000 is a priority, not exactly sure what it does.
        new GzipEncodingProvider(), 1000,
        // Anything under a content-length of 20 will not be gzipped
        Predicates.truePredicate()
        //Predicates.maxContentSize(20) // https://issues.jboss.org/browse/UNDERTOW-1234
      ) )
      .setNext( next );
  }

  public static AccessLogHandler accessLog( HttpHandler next )
  { // see http://undertow.io/javadoc/2.0.x/io/undertow/server/handlers/accesslog/AccessLogHandler.html
    final String format = "%H %h %u \"%r\" %s %Dms %b bytes \"%{i,Referer}\" \"%{i,User-Agent}\"";
    return new AccessLogHandler( next, new Slf4jAccessLogReceiver(), format, Router.class.getClassLoader() );
  }

  public static HttpHandler securityHeaders( HttpHandler next )
  {
    MiddlewareBuilder security = MiddlewareBuilder
      .begin( XFrameOptionsHandlers::deny )
      .next( XXssProtectionHandlers::enableAndBlock )
      .next( XContentTypeOptionsHandler::nosniff )
      .next( handler -> ReferrerPolicyHandlers.policy( handler, ReferrerPolicyHandlers.ReferrerPolicy.STRICT_ORIGIN_WHEN_CROSS_ORIGIN ) );

    // TODO: Only add HSTS if we are not local. We should probably
    // use a self signed cert locally for a better test env
    //        if (Env.LOCAL != Env.get()) {
    security = security.next( handler -> StrictTransportSecurityHandlers.hstsIncludeSubdomains( handler, 31536000L ) );
    //        }
    return security.complete( next );
  }

  public static HttpHandler corsOriginWhitelist( HttpHandler next, Set<String> originWhitelist )
  {
    return ( HttpServerExchange exchange ) -> {
      String origin = Exchange.headers().getHeader( exchange, Headers.ORIGIN ).orElse( "" );
      if( originWhitelist.contains( origin ) )
      {
        Exchange.headers().setHeader( exchange, "Access-Control-Allow-Origin", origin );
      }
      next.handleRequest( exchange );
    };
  }

  public static HttpHandler constantStringHandler( String value )
  {
    return ( HttpServerExchange exchange ) -> {
      exchange.getResponseHeaders().put( Headers.CONTENT_TYPE, "text/plain" );
      exchange.getResponseSender().send( value );
    };
  }

  public static HttpHandler serverErrorHandler()
  {
    return ( HttpServerExchange exchange ) ->
    {
      final String requestLine = RequestLineAttribute.INSTANCE.readAttribute( exchange );
      final Throwable th = exchange.getAttachment( ExceptionHandler.THROWABLE );
      EXCEPTION_LOGGER.error( "general exception thrown at " + requestLine, th );
      Status error = Status.INTERNAL_SERVER_ERROR;
      exchange.setStatusCode( error.getCode() );
      Exchange.body().sendJson( exchange, error );
    };
  }

  public static HttpHandler serverExceptionHandler()
  {
    return ( HttpServerExchange exchange ) ->
    {
      final String requestLine = RequestLineAttribute.INSTANCE.readAttribute( exchange );
      final Status.StatusException ex = (Status.StatusException) exchange.getAttachment( ExceptionHandler.THROWABLE );
      EXCEPTION_LOGGER.error( "api exception thrown at " + requestLine, ex );
      exchange.setStatusCode( ex.getStatus().getCode() );
      Exchange.body().sendJson( exchange, ex.getStatus() );
    };
  }

  public static HttpHandler notFoundHandler()
  {
    return ( HttpServerExchange exchange ) ->
    {
      Status status = Status.NOT_FOUND;
      exchange.setStatusCode( status.getCode() );
      Exchange.body().sendJson( exchange, status );
    };
  }
}
