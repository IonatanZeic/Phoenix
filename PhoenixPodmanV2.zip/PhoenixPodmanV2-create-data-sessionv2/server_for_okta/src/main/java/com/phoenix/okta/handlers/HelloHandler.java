package com.phoenix.okta.handlers;

import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;

public class HelloHandler implements HttpHandler {
    @Override
    public void handleRequest(HttpServerExchange httpServerExchange) throws Exception {
        String method = httpServerExchange.getRequestMethod().toString();
        String response = null;
        if (method.equals("GET")) {
            response = "Hello, world! (GET request)";
        } else if(method.equals("POST")) {
           // String message = httpServerExchange.getQueryParameters().get("message").getFirst();
            response = "Hello, world! (POST request)";
        }
        httpServerExchange.getResponseSender().send(response);
    }
}
