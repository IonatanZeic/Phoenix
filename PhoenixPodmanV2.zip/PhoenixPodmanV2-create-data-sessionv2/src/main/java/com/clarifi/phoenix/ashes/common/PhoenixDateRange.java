package com.clarifi.phoenix.ashes.common;

import com.amazon.ion.IonReader;
import com.amazon.ion.IonStruct;
import com.amazon.ion.IonSystem;
import com.amazon.ion.IonType;

public class PhoenixDateRange {
    private static final PhoenixDateRange EMPTY = new PhoenixDateRange(PhoenixDate.MIN, PhoenixDate.MIN);

    PhoenixDate start, end;

    public PhoenixDateRange() {
        start = PhoenixDate.MIN;
        end = PhoenixDate.MAX;
    }

    public PhoenixDateRange(final PhoenixDate start, final PhoenixDate end) {
        this.start = start;
        this.end = end;
    }

    public PhoenixDate getStart() {
        return start;
    }

    public PhoenixDate getEnd() {
        return end;
    }

    @Override
    public String toString() {
        return String.format("%s - %s", start.toString(), end.toString());
    }

    public PhoenixDateRange withStart(final int year, final int month, final int day) {
        return new PhoenixDateRange(PhoenixDate.of(year, month, day), end);
    }

    public PhoenixDateRange withEnd(final int year, final int month, final int day) {
        return new PhoenixDateRange(start, PhoenixDate.of(year, month, day));
    }

    public static PhoenixDateRange empty() {
        return EMPTY;
    }

    public static PhoenixDateRange startsIn(final int year, final int month, final int day) {
        return new PhoenixDateRange(PhoenixDate.of(year, month, day), PhoenixDate.MAX);
    }

    public static PhoenixDateRange endsIs(final int year, final int month, final int day) {
        return new PhoenixDateRange(PhoenixDate.MIN, PhoenixDate.of(year, month, day));
    }

    public static IonStruct toIon(final PhoenixDateRange range, final IonSystem ion) {
        final PhoenixDate startDate = range.getStart();
        final PhoenixDate endDate = range.getEnd();

        final IonStruct end = ion.newEmptyStruct();
        end.add("year", ion.newInt(endDate.getYear()));
        end.add("month", ion.newInt(endDate.getMonth()));
        end.add("day", ion.newInt(endDate.getDayOfMonth()));

        final IonStruct start = ion.newEmptyStruct();
        start.add("year", ion.newInt(startDate.getYear()));
        start.add("month", ion.newInt(startDate.getMonth()));
        start.add("day", ion.newInt(startDate.getDayOfMonth()));

        final IonStruct result = ion.newEmptyStruct();
        result.add("start-date", start);
        result.add("end-date", end);

        return result;
    }

    public static PhoenixDateRange fromIon(final IonReader reader) {
        // todo: replace with Builder pattern
        PhoenixDate start = PhoenixDate.MIN, end = PhoenixDate.MIN;

        IonType cursor = reader.next();
        while (cursor != IonType.NULL) {
            String field = reader.getFieldName();
            switch (field) {
                case "start-date":
                    reader.stepIn();
                    start = parseIonDate(reader);
                    reader.stepOut();
                    break;

                case "end-date":
                    reader.stepIn();
                    end = parseIonDate(reader);
                    reader.stepOut();
                    break;
            }

            cursor = reader.next();
        }

        return new PhoenixDateRange(start, end);
    }

    private static PhoenixDate parseIonDate(final IonReader reader) {
        int year = 0, month = 0, day = 0;

        IonType cursor = reader.next();
        while (cursor != IonType.NULL) {
            String field = reader.getFieldName();
            switch (field) {
                case "year":
                    year = reader.intValue();
                    break;

                case "month":
                    month = reader.intValue();
                    break;

                case "day":
                    day = reader.intValue();
                    break;
            }

            cursor = reader.next();
        }

        return PhoenixDate.of(year, month, day);
    }
}
