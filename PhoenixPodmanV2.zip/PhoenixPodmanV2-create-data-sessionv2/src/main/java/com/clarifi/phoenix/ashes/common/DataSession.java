package com.clarifi.phoenix.ashes.common;

import java.util.UUID;

public interface DataSession {
    UUID getId();
    PhoenixUser getUser();
    PhoenixDateRange getRange();
    int[] getIssues();
}
