package com.clarifi.phoenix.ashes.server;

import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.StatusCodes;

public class DataSessionFallbackHandler implements HttpHandler {
    @Override
    public void handleRequest(final HttpServerExchange exchange) {
        exchange.setStatusCode(StatusCodes.BAD_REQUEST);
        exchange.endExchange();
    }
}
