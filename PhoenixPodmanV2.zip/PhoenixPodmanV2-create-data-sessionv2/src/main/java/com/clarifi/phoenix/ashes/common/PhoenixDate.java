package com.clarifi.phoenix.ashes.common;

public class PhoenixDate {
    public static PhoenixDate MIN = new PhoenixDate(Short.valueOf((short) 0));
    public static PhoenixDate MAX = new PhoenixDate(Short.MAX_VALUE);

    public int value;

    public PhoenixDate(final int value) {
        this.value = value;
    }

    public int getYear() {
        return 0;
    }

    public int getMonth() {
        return 0;
    }

    public int getDayOfMonth() {
        return 0;
    }

    public static PhoenixDate of(final int year, final int month, final int day) {
        return new PhoenixDate(0);
    }
}
