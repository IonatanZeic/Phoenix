package com.clarifi.phoenix.ashes.client;

import com.amazon.ion.IonStruct;
import com.amazon.ion.IonSystem;
import com.amazon.ion.IonWriter;
import com.amazon.ion.system.IonSystemBuilder;
import com.clarifi.phoenix.ashes.common.*;
import io.undertow.util.StatusCodes;

import java.io.*;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class ClientApp {
    private final String host;
    private final int port;
    private final HttpClient client;
    private final IonSystem ion;

    public ClientApp(final String host, final int port) {
        this.host = host;
        this.port = port;

        client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(5L))
                .version(HttpClient.Version.HTTP_2)
                .followRedirects(HttpClient.Redirect.ALWAYS)
                .build();

        ion = IonSystemBuilder.standard().build();
    }

    private HttpRequest.Builder request(final String path, final Map<String, String> params) {
        final URLBuilder builder = new URLBuilder();
        builder.http().host(host).port(port).path("api2", path);
        builder.addQueryParameters(params);

        return HttpRequest.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .uri(builder.build())
                .timeout(Duration.ofSeconds(5L));
    }

    private DataSession parseDataSession(final InputStream stream) throws IOException {
        final FixedDataSession.Reader reader = new FixedDataSession.JsonReader();

        return reader.read(stream.readAllBytes());
    }

    public PhoenixUser authenticate(final String userName, String password) {
        // todo: implement

        String token = AuthenticationService.getToken(userName,"Phoenix@1234");
        return new PhoenixUser(userName,token);
    }

    private void writeDataSession(final PhoenixUser user,
                                  final PhoenixDateRange range,
                                  final int[] issues,
                                  final OutputStream stream) {
        final IonStruct params = ion.newEmptyStruct();
        params.add("user", PhoenixUser.toIon(user, ion));
        params.add("range", PhoenixDateRange.toIon(range, ion));
        params.add("issues", ion.newList(issues));

        final IonWriter writer = ion.newTextWriter(stream);
        try {
            params.writeTo(writer);

            writer.flush();
            writer.close();

            stream.flush();
        } catch (final Throwable err) {
            // todo: log error
            err.printStackTrace(System.err);
        }
    }

    public DataSession createSmallDataSession(final PhoenixUser user, final PhoenixDateRange range,
                                              final int[] issues) {
         try {
            final HttpRequest.Builder builder = request("data-session/new", null);
            if (user.hasOktaToken()) {
                builder.header("Token", user.getOktaToken());
            }

            final ByteArrayOutputStream stream = new ByteArrayOutputStream();
            writeDataSession(user, range, issues, stream);
            builder.PUT(HttpRequest.BodyPublishers.ofByteArray(stream.toByteArray()));

            final HttpRequest request = builder.build();
            final HttpResponse<InputStream> response = client.send(
                    request, HttpResponse.BodyHandlers.ofInputStream());

            // todo: handle other response codes
            if (response.statusCode() == StatusCodes.OK) {
                return parseDataSession(response.body());
            }
        } catch (final Throwable err) {
            // todo: log error
            err.printStackTrace(System.err);
        }

        return null;
    }

    public DataSession createLargeDataSession(final PhoenixUser user, final PhoenixDateRange range) {
        final int[] issues = new int[32000];
        for (int idx = 0; idx < 32000; idx++) {
            issues[idx] = 1000 + idx;
        }

        try {
            final HttpRequest.Builder builder = request("data-session/new", null);
            builder.header("Content-Encoding", "gzip");
            builder.header("Accept-Encoding", "gzip");

            if (user.hasOktaToken()) {
                builder.header("Phoenix-Auth-Token", user.getOktaToken());
            }

            final ByteArrayOutputStream stream = new ByteArrayOutputStream();
            writeDataSession(user, range, issues, new GZIPOutputStream(stream));
            builder.POST(HttpRequest.BodyPublishers.ofByteArray(stream.toByteArray()));

            builder.timeout(Duration.ofSeconds(30L));
            final HttpRequest request = builder.build();

            final HttpResponse<InputStream> response = client.send(
                    request, HttpResponse.BodyHandlers.ofInputStream());

            // todo: handle other response codes
            if (response.statusCode() == StatusCodes.OK) {
                final List<String> encodings = response.headers().allValues("Content-Encoding");
                if (encodings.contains("gzip")) {
                    return parseDataSession(new GZIPInputStream(response.body()));
                } else {
                    return parseDataSession(response.body());
                }
            }
        } catch (final Throwable err) {
            // todo: log error
            err.printStackTrace(System.err);
        }

        return null;
    }

    public DataSession getDataSession(final UUID id, final PhoenixUser user) {
        final HttpRequest request;
        try {
            final Map<String, String> params = new HashMap<>();
            params.put("userId", user.getId().toString());

            // todo: replace with path builder factory
            final String path = String.format("data-session/get/%s", id.toString());

            final HttpRequest.Builder builder = request(path, params);
            builder.header("Accept-Encoding", "gzip");

            if (user.hasOktaToken()) {
                builder.header("Phoenix-Auth-Token", user.getOktaToken());
            }

            builder.GET();

            request = builder.build();
        } catch (final Throwable err) {
            // todo: log error

            err.printStackTrace(System.err);

            return null;
        }

        final HttpResponse<InputStream> response;
        try {
            response = client.send(request, HttpResponse.BodyHandlers.ofInputStream());
        } catch (final Throwable err) {
            // todo: log error
            err.printStackTrace(System.err);

            return null;
        }

        // todo: handle other response codes
        if (response.statusCode() == StatusCodes.OK) {
            try {
                return parseDataSession(response.body());
            } catch (final Throwable err) {
                err.printStackTrace(System.err);
            }
        }

        return null;
    }

    public void dumpDataSessionCopies(final UUID id, final PhoenixUser user) {
        final HttpRequest request;
        try {
            final Map<String, String> params = new HashMap<>();
            params.put("userId", user.getId().toString());

            // todo: replace with path builder factory
            final String path = String.format("data-session/dump/%s", id.toString());

            final HttpRequest.Builder builder = request(path, params);
            if (user.hasOktaToken()) {
                builder.header("Phoenix-Auth-Token", user.getOktaToken());
            }

            builder.GET();

            request = builder.build();
        } catch (final Throwable err) {
            // todo: log error

            err.printStackTrace(System.err);
            return;
        }

        final HttpResponse<InputStream> response;
        try {
            response = client.send(request, HttpResponse.BodyHandlers.ofInputStream());
        } catch (final Throwable err) {
            // todo: log error
            err.printStackTrace(System.err);
            return;
        }

        // todo: handle other response codes
        if (response.statusCode() == StatusCodes.OK) {
            try {
                System.out.println(new String(response.body().readAllBytes()));
            } catch (final IOException io) {
                io.printStackTrace(System.err);
            }
        }
    }

    public static void main(final String[] args) {
        final ClientApp client = new ClientApp("localhost", 8081);

        final PhoenixUser user = client.authenticate("harsh.vardhan@spglobal.com","Phoenix@1234");

        final DataSession small = client.createSmallDataSession(
                user,
                PhoenixDateRange.startsIn(2024, 1, 1).withEnd(2024, 2, 1),
                new int[] { 1001, 1002, 1003 }
        );

        System.out.println(small);

        final DataSession copy = client.getDataSession(small.getId(), user);
        // todo: deep compare session vs. copy
        System.out.println(copy);

        client.dumpDataSessionCopies(small.getId(), user);

        final DataSession large = client.createLargeDataSession(
                user,
                PhoenixDateRange.startsIn(2023, 1, 1).withEnd(2023, 12, 31)
        );

        System.out.println(large);
    }
}
