package com.clarifi.phoenix.ashes.server;

import com.clarifi.phoenix.ashes.common.DataSession;
import com.clarifi.phoenix.ashes.common.FixedDataSession;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.HeaderValues;
import io.undertow.util.Headers;
import io.undertow.util.StatusCodes;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.configuration.CacheConfiguration;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.UUID;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class DataSessionPostHandler implements HttpHandler {
    private static final String ENCODING_GZIP = "gzip";

    private final ServerApp server;

    public DataSessionPostHandler(final ServerApp server) {
        this.server = server;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) throws Exception {
        final byte[] bytes;

        final HeaderValues requestEncoding = exchange.getRequestHeaders().get(Headers.CONTENT_ENCODING);
        if (requestEncoding.contains(ENCODING_GZIP)) {
            final GZIPInputStream input = new GZIPInputStream(exchange.getInputStream());
            bytes = input.readAllBytes();
        } else {
            final InputStream input = exchange.getInputStream();
            bytes = input.readAllBytes();
        }

        final FixedDataSession.Reader reader = new FixedDataSession.JsonReader();
        final FixedDataSession session = reader.read(bytes);

        final Ignite ignite = server.getIgnite();
        final String userCacheName = String.format(
                "%s:%s", ServerApp.PREFIX_CACHE_USER_DATA_SESSIONS, session.getUser().getId());

        IgniteCache<UUID, DataSession> userDataSessionCache = ignite.cache(userCacheName);
        if (userDataSessionCache == null) {
            final CacheConfiguration<UUID, DataSession> cacheCfg = new CacheConfiguration<>(userCacheName);
            cacheCfg.setCacheMode(CacheMode.REPLICATED);

            userDataSessionCache = ignite.createCache(cacheCfg);
            userDataSessionCache.put(session.getId(), session);
        } else {
            userDataSessionCache.put(session.getId(), session);
        }

        System.out.printf("Data session created: %s\n", session);

        final HeaderValues acceptEncoding = exchange.getRequestHeaders().get(Headers.ACCEPT_ENCODING);

        final FixedDataSession.Writer writer = new FixedDataSession.JsonWriter(session);

        final ByteArrayOutputStream output = new ByteArrayOutputStream();
        if (acceptEncoding.contains(ENCODING_GZIP)) {
            exchange.getResponseHeaders().put(Headers.CONTENT_ENCODING, ENCODING_GZIP);

            writer.write(new GZIPOutputStream(output));
        } else {
            writer.write(output);
        }

        final byte[] payload = output.toByteArray();

        exchange.getResponseHeaders().put(Headers.CONTENT_TYPE, "text/json");
        exchange.getResponseHeaders().put(Headers.CONTENT_LENGTH, Integer.toString(payload.length));

        exchange.setStatusCode(StatusCodes.OK);
        exchange.setResponseContentLength(payload.length);

        exchange.getResponseSender().send(ByteBuffer.wrap(payload));

        exchange.endExchange();
    }
}
