package com.clarifi.phoenix.ashes.task;

import com.clarifi.phoenix.ashes.common.Common;
import com.clarifi.phoenix.ashes.data.TimeSeriesData;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataCache;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.CachePeekMode;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.lang.IgniteRunnable;
import org.apache.ignite.resources.IgniteInstanceResource;

import java.util.UUID;

/**
 * A computation tasks that prints out a node ID and some details about its OS and JRE.
 * Plus, the code shows how to access data stored in a cache from the computation task.
 */
class SumDataItemsTask implements IgniteRunnable {
  private final int _resultItemId;
  private final int[] _issueRange;
  private final int[] _dataItemRange;

  @IgniteInstanceResource
  Ignite ignite;

  public SumDataItemsTask(int resultItemId, int[] issueRange, int[] dataItemRange) {
    _resultItemId = resultItemId;

    _issueRange = new int[2];
    _issueRange[0] = issueRange[0];
    _issueRange[1] = issueRange[1];

    _dataItemRange = new int[2];
    _dataItemRange[0] = dataItemRange[0];
    _dataItemRange[1] = dataItemRange[1];
  }

  @Override
  public void run() {
    System.out.println(">> Executing the Sum Data Items Task");

    UUID nodeId = ignite.cluster().localNode().id();
    System.out.println("\tNode ID: " + nodeId);

    IgniteCache<TimeSeriesDataKey, TimeSeriesData> tsCache = ignite.cache(Common.TIMESERIES_DATA_CACHE);

    if (tsCache == null) {
      throw new IllegalStateException("Time series data cache " + Common.TIMESERIES_DATA_CACHE + " is not found, exiting");
    }

    sumDataItems(tsCache);
  }

  private void sumDataItems(IgniteCache<TimeSeriesDataKey, TimeSeriesData> tsCache)
  {
      for (int i = _issueRange[0]; i <= _issueRange[1]; ++i) {
        int issueId = TimeSeriesDataCache.generateIssueId(i);
        sumDataItems(tsCache, issueId);
      }
  }

  private void sumDataItems(IgniteCache<TimeSeriesDataKey, TimeSeriesData> tsCache, int issueId) {
    int startItem = _dataItemRange[0];
    int stopItem = _dataItemRange[1];

    TimeSeriesData result = null;

    for (int i = startItem; i <= stopItem; ++i) {
      int dataItemId = TimeSeriesDataCache.generateDataItemId(i);
      TimeSeriesDataKey key = new TimeSeriesDataKey(issueId, dataItemId);

      TimeSeriesData ts = tsCache.localPeek(key, CachePeekMode.PRIMARY);
      if (ts == null) {
        return;
      }

      if (result == null) {
        result = new TimeSeriesData(ts);
      }
      else {
        add(result, ts);
      }
    }

    System.out.println("\tProcessed issueId = " + issueId);
    TimeSeriesDataKey key = new TimeSeriesDataKey(issueId, _resultItemId);
    tsCache.put(key, result);
  }

  private static void add(TimeSeriesData result, TimeSeriesData ts) {
    for (int i = 0; i < result.values.length; ++i) {
      result.values[i] += ts.values[i];
    }
  }

  public static void main(String[] args) throws IgniteException {
    IgniteConfiguration cfg = Common.igniteClientConfiguration();

    // Starting the node
    Ignite ignite = Ignition.start(cfg);

    try {
      int[] dataRange = new int[] {1, 50};
      int[] issueRange = new int[] {1, 1000};

      int resultItemId = TimeSeriesDataCache.generateDerivedDataItemId(2);

      long startTime = System.currentTimeMillis();
      ignite.compute(ignite.cluster().forServers()).broadcast(new SumDataItemsTask(resultItemId, issueRange, dataRange));
      long stopTime = System.currentTimeMillis();

      long execTime = stopTime - startTime;
      System.out.println(">> Compute task is executed, check for output on the server nodes.");
      System.out.println(">> Execution time is " + execTime + " ms");

    }
    finally {
      // Disconnect from the cluster.
      ignite.close();
    }
  }

}
