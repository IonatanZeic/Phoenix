package com.clarifi.phoenix.ashes.common;

import java.util.UUID;

public class BasketDataSession implements DataSession {
    // todo: Will use a basket to get the issue ids

    @Override
    public UUID getId() {
        return null;
    }

    @Override
    public PhoenixUser getUser() {
        return null;
    }

    @Override
    public PhoenixDateRange getRange() {
        return null;
    }

    @Override
    public int[] getIssues() {
        return new int[0];
    }
}
