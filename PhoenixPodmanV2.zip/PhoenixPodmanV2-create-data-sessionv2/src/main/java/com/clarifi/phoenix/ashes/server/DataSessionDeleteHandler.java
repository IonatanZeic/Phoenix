package com.clarifi.phoenix.ashes.server;

import com.clarifi.phoenix.ashes.common.DataSession;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.PathTemplateMatch;
import io.undertow.util.StatusCodes;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;

import java.util.UUID;

public class DataSessionDeleteHandler implements HttpHandler {
    private final ServerApp server;

    public DataSessionDeleteHandler(final ServerApp server) {
        this.server = server;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) {
        //-- Data sessionId is in the path (REST request)
        PathTemplateMatch pathMatch = exchange.getAttachment(PathTemplateMatch.ATTACHMENT_KEY);
        String sessionId = pathMatch.getParameters().get("sessionId");

        //-- UserId is passed as a query parameter
        String userId = exchange.getQueryParameters().get("userId").getFirst();

        final Ignite ignite = server.getIgnite();
        final String userCacheName = String.format("%s:%s", ServerApp.PREFIX_CACHE_USER_DATA_SESSIONS, userId);
        final IgniteCache<UUID, DataSession> userDataSessionCache = ignite.cache(userCacheName);
        if (userDataSessionCache == null) {
            exchange.setStatusCode(StatusCodes.NOT_FOUND);

            exchange.getResponseSender().send(String.format("User with id '%s' does have any sessions", userId));
        } else {
            final UUID sessionUID = UUID.fromString(sessionId);
            final DataSession existing = userDataSessionCache.get(sessionUID);

            if (existing == null) {
                exchange.setStatusCode(StatusCodes.NOT_FOUND);

                exchange.getResponseSender().send(String.format(
                        "User with id '%s' does have session with id '%s'", userId, sessionUID));
            } else {
                userDataSessionCache.remove(sessionUID);

                exchange.setStatusCode(StatusCodes.OK);

                exchange.getResponseSender().send(String.format(
                        "Data session '%s' for user '%s' removed", sessionId, userId));
            }
        }

        exchange.endExchange();
    }
}
