package com.clarifi.phoenix.ashes.data;

import org.apache.ignite.cache.affinity.AffinityKeyMapped;

public class TimeSeriesDataKey {
  @AffinityKeyMapped
  public final int issueId;

  public final int dataItemId;

  public TimeSeriesDataKey(int issueId, int dataItemId) {
    this.issueId = issueId;
    this.dataItemId = dataItemId;
  }
}
