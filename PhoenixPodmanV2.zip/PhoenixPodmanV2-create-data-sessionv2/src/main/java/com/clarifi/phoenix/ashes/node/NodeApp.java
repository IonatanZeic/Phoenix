package com.clarifi.phoenix.ashes.node;

import org.apache.ignite.Ignite;
import org.apache.ignite.Ignition;
import org.apache.ignite.configuration.IgniteConfiguration;

import java.util.concurrent.TimeUnit;

public class NodeApp {
    public static void main(final String[] args) {
        final IgniteConfiguration cfg = new IgniteConfiguration();

        cfg.setClientMode(false);
        cfg.setPeerClassLoadingEnabled(true);
        final int serverId = Integer.parseInt(args[0]);
        final String serverName = "server-" + serverId;
        cfg.setIgniteInstanceName(serverName);
        cfg.setWorkDirectory("c:/tmp/" + serverName);

//        final DataStorageConfiguration cfgStorage = new DataStorageConfiguration();
//        final DataRegionConfiguration cfgDataRegion = cfgStorage.getDefaultDataRegionConfiguration();
//        cfgDataRegion.setMaxSize(1024 * 1024 * 1024);
//        cfgDataRegion.setPersistenceEnabled(true);
//
//        cfg.setDataStorageConfiguration(cfgStorage);

        final Ignite ignite = Ignition.start(cfg);
        System.out.printf(
                ">> Started the server node: Name %s; Id: %s\n",
                serverName,
                ignite.cluster().node().id()
        );

        System.out.printf("\tNode ID: %s\n\tOS: %s\tJRE: %s\n",
                ignite.cluster().localNode().id(),
                System.getProperty("os.name"),
                System.getProperty("java.runtime.name")
        );

        while (ignite.active()) {
            try {
                TimeUnit.SECONDS.sleep(10L);
            } catch (final InterruptedException ignore) {
            }
        }

        ignite.close();

    }
}
