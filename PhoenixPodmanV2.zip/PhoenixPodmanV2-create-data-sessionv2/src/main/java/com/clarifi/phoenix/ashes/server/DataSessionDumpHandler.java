package com.clarifi.phoenix.ashes.server;

import com.clarifi.phoenix.ashes.common.DataSession;
import com.clarifi.phoenix.ashes.common.FixedDataSession;
import com.clarifi.phoenix.ashes.task.DumpDataSessionTask;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.Headers;
import io.undertow.util.PathTemplateMatch;
import io.undertow.util.StatusCodes;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteCompute;
import org.apache.ignite.IgniteCountDownLatch;
import org.apache.ignite.cluster.ClusterGroup;

import javax.cache.Cache;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

public class DataSessionDumpHandler implements HttpHandler {
    private static final long DEFAULT_TIMEOUT_S = 30L;

    private final ServerApp server;
    private long timeoutS;

    public DataSessionDumpHandler(final ServerApp server) {
        this.server = server;

        timeoutS = DEFAULT_TIMEOUT_S;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) {
        //-- Data sessionId is in the path (REST request)
        PathTemplateMatch pathMatch = exchange.getAttachment(PathTemplateMatch.ATTACHMENT_KEY);
        String sessionId = pathMatch.getParameters().get("sessionId");

        //-- UserId is passed as a query parameter
        String userId = exchange.getQueryParameters().get("userId").getFirst();

        final Ignite ignite = server.getIgnite();
        final String userCacheName = String.format(
                "%s:%s", ServerApp.PREFIX_CACHE_USER_DATA_SESSIONS, userId);

        final ClusterGroup group = ignite.cluster().forServers();
        final IgniteCompute compute = ignite.compute(group);

        // todo: generate name based on request; otherwise there will be clashes
        final IgniteCountDownLatch latch = ignite.countDownLatch(
                "mytestlatch", group.nodes().size(), true, true);
        final IgniteCache<String, DataSession> results = ignite.getOrCreateCache("myresults");
        results.clear();

        final Executor executor = server.getExecutor();
        executor.execute(new Runnable() {
            @Override
            public void run() {
                compute.broadcast(new DumpDataSessionTask(userCacheName, sessionId));
            }
        });

        try {
            final boolean success = latch.await(timeoutS, TimeUnit.SECONDS);
            if (success) {
                dumpSessions(results, exchange);
            } else {
                exchange.setStatusCode(StatusCodes.REQUEST_TIME_OUT);
                exchange.getResponseSender().send("Timed out while processing request");
                exchange.endExchange();
            }
        } catch (final Throwable err) {
            err.printStackTrace(System.err);
        } finally {
            results.close();
            latch.close();
        }
    }

    private void dumpSessions(final IgniteCache<String, DataSession> results, final HttpServerExchange exchange) {
        final ByteArrayOutputStream output = new ByteArrayOutputStream();

        final Iterator<Cache.Entry<String, DataSession>> iterator = results.iterator();
        while (iterator.hasNext()) {
            final Cache.Entry<String, DataSession> cursor = iterator.next();

            final String nodeId = cursor.getKey();
            final DataSession session = cursor.getValue();

            output.writeBytes(String.format(
                    "Node: %s, Data session: %s\n", nodeId, session.getId()).getBytes(StandardCharsets.UTF_8));

            final FixedDataSession.Writer writer = new FixedDataSession.JsonWriter((FixedDataSession) session);
            writer.write(output);

            output.writeBytes(new String("\n---\n").getBytes(StandardCharsets.UTF_8));
        }

        final byte[] payload = output.toByteArray();

        exchange.getResponseHeaders().put(Headers.CONTENT_LENGTH, Integer.toString(payload.length));
        exchange.getResponseHeaders().put(Headers.CONTENT_TYPE, "text");

        exchange.setStatusCode(StatusCodes.OK);
        exchange.setResponseContentLength(payload.length);

        exchange.getResponseSender().send(ByteBuffer.wrap(payload));

        exchange.endExchange();
    }
}
