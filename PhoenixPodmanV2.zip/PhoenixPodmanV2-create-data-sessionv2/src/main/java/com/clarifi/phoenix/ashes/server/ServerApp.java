package com.clarifi.phoenix.ashes.server;

import io.swagger.annotations.ApiOperation;
import org.apache.ignite.Ignite;
import org.apache.ignite.Ignition;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi;
import org.apache.ignite.spi.discovery.tcp.ipfinder.multicast.TcpDiscoveryMulticastIpFinder;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.FilterHolder;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.servlets.CrossOriginFilter;

import javax.servlet.DispatcherType;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collections;
import java.util.EnumSet;
import java.util.concurrent.*;

/*
On some machines you may need to add this JVM Options to your Run configuration in order for the ignite node to run
--add-opens
java.base/java.nio=ALL-UNNAMED
--add-opens
java.base/java.util=ALL-UNNAMED
**/


public class ServerApp {

    public static final String PATH_API2 = "/api2";
    public static final String PREFIX_CACHE_USER_DATA_SESSIONS = "user-data-sessions";

    private final BlockingQueue<Runnable> queue;
    private final Executor executor;
    private static final Ignite ignite = startIgnite();

    public ServerApp() {
        // Initialize executor
        queue = new ArrayBlockingQueue<>(32);
        executor = new ThreadPoolExecutor(
                2, 4, 5L, TimeUnit.MINUTES, queue);
    }

    public Ignite getIgnite() {
        return ignite;
    }

    public Executor getExecutor() {
        return executor;
    }

    private static Ignite startIgnite() {
        IgniteConfiguration cfg = new IgniteConfiguration();
        cfg.setClientMode(true);
        cfg.setPeerClassLoadingEnabled(true);
        /* IMPORTANT!
         * If the error "Remote node has peer class loading enabled flag different from local node"
         * appears, you should edit the file default-config.xml, adding the entry:
         * <property name="peerClassLoadingEnabled" value="true" />
         */
        cfg.setWorkDirectory("/home/ioni/SERVUSTECH/2024/Phoenix/PhoenixPodmanV2-create-data-sessionv2/api-server");
        //Keep In Mind to always change the work directory path according to your current directory location

        // Network configuration
        TcpDiscoverySpi spi = new TcpDiscoverySpi();
        TcpDiscoveryMulticastIpFinder ipFinder = new TcpDiscoveryMulticastIpFinder();
        ipFinder.setAddresses(Collections.singletonList("127.0.0.1:47500..47509"));
        spi.setIpFinder(ipFinder);
        cfg.setDiscoverySpi(spi);

        // Start Ignite
        return Ignition.start(cfg);
    }

  public static void main(String[] args) {
      System.out.println("hello World");
        startServer();
    }

    private static void startServer() {
        try {
            Server server = new Server(8083);

            ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
            context.setContextPath("/");
            configureCors(context);

            context.addServlet(new ServletHolder(new SwaggerUIServlet()), "/swagger-ui/*");
            context.addServlet(new ServletHolder(new ApiResourceServlet()), PATH_API2 + "/*");

            server.setHandler(context);
            server.start();
            System.out.println("AM PORNIT");
        } catch (Exception e) {
            System.out.println("AM PROBLEME");

            e.printStackTrace();
        }
    }

    private static void configureCors(ServletContextHandler context) {
        FilterHolder holder = context.addFilter(CrossOriginFilter.class, "/*", EnumSet.of(DispatcherType.REQUEST));
        holder.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
        holder.setInitParameter(CrossOriginFilter.ACCESS_CONTROL_ALLOW_ORIGIN_HEADER, "*");
        holder.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,POST,PUT,DELETE,HEAD,OPTIONS");
        holder.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "X-Requested-With,Content-Type,Accept,Origin");
    }

    @Path(PATH_API2)
    public static class ApiResourceServlet extends HttpServlet {

        @ApiOperation(value = "Create a new data session")
        @POST
        @Path("/data-session/new")
        @Consumes(MediaType.APPLICATION_JSON)
        @Produces(MediaType.APPLICATION_JSON)
        public void createDataSession(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            // Implement creation logic
        }

        @ApiOperation(value = "Get data session by ID")
        @GET
        @Path("/data-session/get/{id}")
        @Produces(MediaType.APPLICATION_JSON)
        public void getDataSession(@PathParam("id") String id, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            // Replace this comment with your logic to retrieve data session by ID
            String dataSession = "Data session retrieved for ID: " + id;

            // Write the data session as JSON response
            response.setContentType("application/json");
            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write("{\"dataSession\": \"" + dataSession + "\"}");
        }

        @ApiOperation(value = "Update data session")
        @PUT
        @Path("/data-session/post")
        @Consumes(MediaType.APPLICATION_JSON)
        @Produces(MediaType.APPLICATION_JSON)
        public void updateDataSession(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            // Implement update logic
        }

        @ApiOperation(value = "Delete data session by ID")
        @DELETE
        @Path("/data-session/delete/{id}")
        @Produces(MediaType.APPLICATION_JSON)
        public void deleteDataSession(@PathParam("id") String id, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            // Implement deletion logic
        }

        @ApiOperation(value = "Dump all data sessions")
        @GET
        @Path("/data-session/dump")
        @Produces(MediaType.APPLICATION_JSON)
        public void dumpDataSessions(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            // Implement dump logic
        }
    }

    static class SwaggerUIServlet extends HttpServlet {
        private static final String SWAGGER_UI_FOLDER = "/home/ioni/SERVUSTECH/2024/Phoenix/PhoenixPodmanV2-create-data-sessionv2/static_web/swagger";

        @Override
        protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            String requestUri = req.getRequestURI();
            String fileName = requestUri.substring(requestUri.lastIndexOf('/') + 1);
            File file = new File(SWAGGER_UI_FOLDER, fileName);

            if (file.exists()) {
                // Set content type based on file extension
                String contentType = getContentType(fileName);
                resp.setContentType(contentType);

                // Copy file contents to response output stream
                try (FileInputStream fis = new FileInputStream(file);
                     OutputStream os = resp.getOutputStream()) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = fis.read(buffer)) != -1) {
                        os.write(buffer, 0, bytesRead);
                    }
                }
            } else {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        }

        private String getContentType(String fileName) {
            if (fileName.endsWith(".html")) {
                return "text/html";
            } else if (fileName.endsWith(".css")) {
                return "text/css";
            } else if (fileName.endsWith(".js")) {
                return "application/javascript";
            } else {
                return "application/octet-stream";
            }
        }

   }
}
