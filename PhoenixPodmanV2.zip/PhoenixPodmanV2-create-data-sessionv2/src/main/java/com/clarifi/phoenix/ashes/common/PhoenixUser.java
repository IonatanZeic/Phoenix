package com.clarifi.phoenix.ashes.common;

import com.amazon.ion.IonReader;
import com.amazon.ion.IonStruct;
import com.amazon.ion.IonSystem;
import com.amazon.ion.IonType;

import java.util.UUID;

public class PhoenixUser {
    private final UUID id;
    private String userName;
    private String oktaToken;

    public PhoenixUser(final String value) {
        this.id = UUID.fromString(value);
    }

    public PhoenixUser() {
        this.id = UUID.randomUUID();
        setName("N/A");
    }
    public PhoenixUser(String userName, String oktaToken ){
        this.userName = userName;
        this.oktaToken = oktaToken;
        this.id = UUID.randomUUID();
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return userName;
    }

    public void setName(final String value) {
        this.userName = value;
    }

    public boolean hasOktaToken() {
        if (oktaToken == null) {
            return false;
        } else if (oktaToken.isBlank() || oktaToken.isEmpty()) {
            return false;
        }

        return true;
    }

    public String getOktaToken() {
        return oktaToken;
    }

    public void setOktaToken(final String value) {
        this.oktaToken = value;
    }

    @Override
    public String toString() {
        return String.format("%s [%s]", id.toString(), userName);
    }

    public static PhoenixUser random() {
        return new PhoenixUser();
    }

    public static IonStruct toIon(final PhoenixUser userId, final IonSystem ion) {
        final IonStruct result = ion.newEmptyStruct();
        result.add("id", ion.newString(userId.id.toString()));
        result.add("name", ion.newString(userId.getName()));
        result.add("token", ion.newString(userId.getOktaToken()));

        return result;
    }

    public static PhoenixUser fromIon(final IonReader reader) {
        // todo: replace with Builder pattern
        String uid = "N/A";
        String name = null, token = null;

        IonType cursor = reader.next();
        while (cursor != IonType.NULL) {
            String field = reader.getFieldName();
            switch (field) {
                case "id":
                    uid = reader.stringValue();
                    break;

                case "name":
                    name = reader.stringValue();
                    break;

                case "token":
                    token = reader.stringValue();
                    break;
            }
            cursor = reader.next();
        }

        final PhoenixUser result = new PhoenixUser(uid);
        result.setName(name);
        result.setOktaToken(token);

        return result;
    }
}
