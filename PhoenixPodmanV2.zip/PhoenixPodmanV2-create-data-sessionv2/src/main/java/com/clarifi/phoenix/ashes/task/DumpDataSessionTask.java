package com.clarifi.phoenix.ashes.task;

import com.clarifi.phoenix.ashes.common.DataSession;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteCountDownLatch;
import org.apache.ignite.cluster.ClusterNode;
import org.apache.ignite.lang.IgniteRunnable;
import org.apache.ignite.resources.IgniteInstanceResource;

import java.util.UUID;

public class DumpDataSessionTask implements IgniteRunnable {
    @IgniteInstanceResource
    Ignite ignite;

    private final String userCacheName;
    private final String sessionId;

    public DumpDataSessionTask(final String userCacheName, final String sessionId) {
        this.userCacheName = userCacheName;
        this.sessionId = sessionId;
    }

    @Override
    public void run() {
        // todo: refactor to execute on a separate thread pool in the NodeApp

        final ClusterNode node = ignite.cluster().localNode();
        final IgniteCountDownLatch latch = ignite.countDownLatch("mytestlatch", 0, false, false);

        final IgniteCache<UUID, DataSession> cache = ignite.cache(userCacheName);
        if (cache == null) {
            latch.countDown();
            return;
        }

        final IgniteCache<String, DataSession> results = ignite.cache("myresults");

        final DataSession session = cache.get(UUID.fromString(sessionId));
        results.put(node.id().toString(), session);

        latch.countDown();
    }
}
