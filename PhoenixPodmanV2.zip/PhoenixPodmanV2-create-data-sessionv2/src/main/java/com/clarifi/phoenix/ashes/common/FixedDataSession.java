package com.clarifi.phoenix.ashes.common;

import com.amazon.ion.*;
import com.amazon.ion.system.IonSystemBuilder;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

public class FixedDataSession implements DataSession {
    private final UUID id;
    private final PhoenixUser user;
    private PhoenixDateRange range;
    private int[] issues;

    public FixedDataSession(final UUID id, final PhoenixUser user) {
        this.id = id;
        this.user = user;

        range = PhoenixDateRange.empty();
        issues = new int[] {};
    }

    @Override
    public UUID getId() {
        return id;
    }

    public PhoenixUser getUser() {
        return user;
    }

    public PhoenixDateRange getRange() {
        return range;
    }

    public void setRange(final PhoenixDateRange value) {
        this.range = value;
    }

    @Override
    public int[] getIssues() {
        return issues;
    }

    public void setIssues(final List<Integer> values) {
        // https://stackoverflow.com/questions/960431/how-can-i-convert-listinteger-to-int-in-java

        final int[] temp = new int[values.size()];
        values.forEach(new Consumer<Integer>() {
            int index = 0;
            @Override
            public void accept(final Integer integer) {
                temp[index++] = integer.intValue();
            }
        });

        this.issues = temp;
    }

    public void addIssues(final List<Integer> values) {
        final int[] temp = new int[issues.length + values.size()];

        System.arraycopy(issues, 0, temp, 0, issues.length);

        values.forEach(new Consumer<Integer>() {
            int index = issues.length;
            @Override
            public void accept(final Integer integer) {
                temp[index++] = integer.intValue();
            }
        });

        this.issues = temp;
    }

    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("UUID: ").append(id.toString());
        builder.append(", User: ").append(user.toString());
        builder.append(", Date range: ").append(range.toString());
        builder.append(", Issues: ");

        for (int idx = 0; idx < Math.min(16, issues.length); idx++) {
            builder.append(Integer.toString(issues[idx]));
            if (idx < issues.length - 1) {
                builder.append(',');
            }
        }

        if (issues.length > 16) {
            builder.append("...");
        }

        return builder.toString();
    }

    public static interface Reader {
        FixedDataSession read(byte[] bytes);
    }

    public static class JsonReader implements Reader {
        private PhoenixUser user = null;
        private PhoenixDateRange range = PhoenixDateRange.empty();
        private List<Integer> issues = new ArrayList<>();

        @Override
        public FixedDataSession read(final byte[] bytes) {
            final IonSystem ion = IonSystemBuilder.standard().build();

            UUID uid = UUID.randomUUID();

            try (final IonReader reader = ion.newReader(bytes)) {
                IonType cursor = reader.next();
                reader.stepIn();

                do {
                    cursor = reader.next();
                    if (cursor != null) {
                        switch (reader.getFieldName()) {
                            case "id":
                                uid = UUID.fromString(reader.stringValue());
                                break;

                            case "user":
                                parseUser(reader);
                                break;

                            case "range":
                                parseRange(reader);
                                break;

                            case "issues":
                                parseIssues(reader);
                                break;
                        }
                    }
                } while (cursor != null);

                reader.stepOut();
            } catch (final Throwable err) {
                err.printStackTrace(System.err);
            }

            final FixedDataSession result = new FixedDataSession(uid, user);
            result.setRange(range);
            result.setIssues(issues);

            return result;
        }

        private void parseUser(final IonReader reader) {
            reader.stepIn();

            UUID id = null;
            String name = "N/A";
            String token = null;

            IonType cursor = reader.next();
            while (cursor != null) {
                switch (reader.getFieldName()) {
                    case "id":
                        id = UUID.fromString(reader.stringValue());
                        break;

                    case "name":
                        name = reader.stringValue();
                        break;

                    case "token":
                        token = reader.stringValue();
                        break;
                }

                cursor = reader.next();
            }

            reader.stepOut();

            user = new PhoenixUser(id.toString());
            user.setName(name);
            user.setOktaToken(token);
        }

        private void parseRange(final IonReader reader) {
            reader.stepIn();

            PhoenixDate start = PhoenixDate.MIN, end = PhoenixDate.MIN;

            IonType cursor = reader.next();
            while (cursor != null) {
                switch (reader.getFieldName()) {
                    case "start-date":
                        start = parseLocalDate(reader);
                        break;

                    case "end-date":
                        end = parseLocalDate(reader);
                        break;
                }

                cursor = reader.next();
            }

            reader.stepOut();

            range = new PhoenixDateRange(start, end);
        }

        private void parseIssues(final IonReader reader) {
            reader.stepIn();

            issues.clear();

            IonType cursor = reader.next();
            while (cursor != null) {
                issues.add(Integer.valueOf(reader.intValue()));
                cursor = reader.next();
            }

            reader.stepOut();
        }

        private PhoenixDate parseLocalDate(final IonReader reader) {
            reader.stepIn();

            int year = 0, month = 0, day = 0;

            IonType cursor = reader.next();
            while (cursor != null) {
                switch (reader.getFieldName()) {
                    case "year":
                        year = reader.intValue();
                        break;

                    case "month":
                        month = reader.intValue();
                        break;

                    case "day":
                        day = reader.intValue();
                        break;
                }

                cursor = reader.next();
            }

            reader.stepOut();

            return PhoenixDate.of(year, month, day);
        }
    }

    public static interface Writer {
        void write(OutputStream stream);
    }

    public static class JsonWriter implements Writer {
        private final FixedDataSession session;

        public JsonWriter(final FixedDataSession session) {
            this.session = session;
        }

        @Override
        public void write(final OutputStream stream) {
            final IonSystem ion = IonSystemBuilder.standard().build();

            final IonStruct params = ion.newEmptyStruct();
            params.add("id", ion.newString(session.getId().toString()));
            params.add("user", PhoenixUser.toIon(session.getUser(), ion));
            params.add("range", PhoenixDateRange.toIon(session.getRange(), ion));
            params.add("issues", ion.newList(session.getIssues()));

            final IonWriter writer = ion.newTextWriter(stream);
            try {
                params.writeTo(writer);
                writer.flush();
                writer.close();
            }  catch (final Throwable err) {
                err.printStackTrace(System.err);
            }
        }
    }
}
